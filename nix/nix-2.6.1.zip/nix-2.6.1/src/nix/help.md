R""(

# Examples

* Show help about `nix` in general:

  ```console
  # nix help
  ```

* Show help about a particular subcommand:

  ```console
      # nix help flake info
  ```

)""
