#include "types.hh"

namespace nix {

std::string renderMarkdownToTerminal(std::string_view markdown);

}
