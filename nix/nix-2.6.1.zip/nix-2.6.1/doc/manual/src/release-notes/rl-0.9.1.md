# Release 0.9.1 (2005-09-20)

This bug fix release addresses a problem with the ATerm library when the
`--with-aterm` flag in `configure` was *not* used.
