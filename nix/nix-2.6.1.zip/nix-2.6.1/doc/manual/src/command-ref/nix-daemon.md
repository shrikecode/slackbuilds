# Name

`nix-daemon` - Nix multi-user support daemon

# Synopsis

`nix-daemon`

# Description

The Nix daemon is necessary in multi-user Nix installations. It performs
build actions and other operations on the Nix store on behalf of
unprivileged users.
