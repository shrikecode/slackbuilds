# Files

This section lists configuration files that you can use when you work
with Nix.
