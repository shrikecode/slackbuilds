This section describes how to install and configure Nix for first-time
use.
